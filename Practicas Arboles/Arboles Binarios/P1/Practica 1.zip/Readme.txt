Estimado Jose,

ninguna duda al respecto por el momento. Me queda por terminar el ejercicio 7 que he realizado más deprisa y revisaré proximamente, aunque sé lo que me pide.

Atentamente,
un saludo.