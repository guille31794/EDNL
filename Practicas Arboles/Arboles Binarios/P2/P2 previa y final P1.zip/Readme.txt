Estimado Jose,

aún estoy planteando el ejercicio 3. 
No he tenido tiempo de pelearme con el 4, pero lo haré en breves.

Atentamente,
un saludo.