#include <fstream>
#include <iostream>
#include "../abin.h"
#include "../abin_E-S.h"

using namespace std;

// a)
typedef union Expression
{
    char math_operator;
    double operand;
} Expression;

// b)
double computeTree(Abin<Expression>& T)
{
    return T.arbolVacio() ? 0.0 : computeTree(T, T.raiz());
}

double computeTree(Abin<Expression>& T, Abin<Expression>::nodo n)
{
    if(Abin<Expression>::NODO_NULO == n)
}

int main(int argc, char const *argv[])
{



    return 0;
}